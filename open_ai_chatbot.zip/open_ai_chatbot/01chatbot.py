import openai

openai.api_key = "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"

completion = openai.ChatCompletion.create(model="gpt-3.5-turbo",messages=[{"role":"user", "content":"Write an essay about penguins"}])
print(completion.choices[0].message.content)